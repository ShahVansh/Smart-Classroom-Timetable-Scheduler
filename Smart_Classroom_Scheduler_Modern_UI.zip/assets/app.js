;(() => {
  const state = {
    courses: [],
    rooms: [],
    faculty: [],
    constraints: { days: ['Mon','Tue','Wed','Thu','Fri'], slots: 6, slotLen: 60, windows: '' },
    timetable: []
  };

  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const id = btn.getAttribute('data-tab');
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.add('hidden'));
      document.getElementById('tab-' + id).classList.remove('hidden');
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('bg-zinc-50','dark:bg-zinc-800'));
      btn.classList.add('bg-zinc-50','dark:bg-zinc-800');
    });
  });

  const tbody = id => document.getElementById(id);
  const renderTable = () => {
    const cBody = tbody('coursesTable');
    if (cBody) cBody.innerHTML = state.courses.map((c,i)=>`
      <tr class="border-b border-zinc-100 dark:border-zinc-800">
        <td class="py-2 pr-6">${c.code}</td>
        <td class="py-2 pr-6">${c.title}</td>
        <td class="py-2 pr-6">${c.hours}</td>
        <td class="py-2 pr-6"><button data-i="${i}" class="del-course text-red-600">Delete</button></td>
      </tr>`).join('');
    const rBody = tbody('roomsTable');
    if (rBody) rBody.innerHTML = state.rooms.map((r,i)=>`
      <tr class="border-b border-zinc-100 dark:border-zinc-800">
        <td class="py-2 pr-6">${r.name}</td>
        <td class="py-2 pr-6">${r.capacity}</td>
        <td class="py-2 pr-6">${r.equip}</td>
        <td class="py-2 pr-6"><button data-i="${i}" class="del-room text-red-600">Delete</button></td>
      </tr>`).join('');
    const fBody = tbody('facultyTable');
    if (fBody) fBody.innerHTML = state.faculty.map((f,i)=>`
      <tr class="border-b border-zinc-100 dark:border-zinc-800">
        <td class="py-2 pr-6">${f.name}</td>
        <td class="py-2 pr-6">${f.courses}</td>
        <td class="py-2 pr-6">${f.load}</td>
        <td class="py-2 pr-6"><button data-i="${i}" class="del-faculty text-red-600">Delete</button></td>
      </tr>`).join('');
    document.querySelectorAll('.del-course').forEach(b => b.onclick = () => { state.courses.splice(+b.dataset.i,1); renderTable(); });
    document.querySelectorAll('.del-room').forEach(b => b.onclick = () => { state.rooms.splice(+b.dataset.i,1); renderTable(); });
    document.querySelectorAll('.del-faculty').forEach(b => b.onclick = () => { state.faculty.splice(+b.dataset.i,1); renderTable(); });
  };

  const addCourse = document.getElementById('addCourse');
  if (addCourse) addCourse.addEventListener('click', () => {
    const code = document.getElementById('c-code').value.trim();
    const title = document.getElementById('c-title').value.trim();
    const hours = +document.getElementById('c-hours').value || 0;
    if (!code || !title || !hours) return alert('Please fill course code, title, and hours.');
    state.courses.push({ code, title, hours });
    renderTable();
  });
  const addRoom = document.getElementById('addRoom');
  if (addRoom) addRoom.addEventListener('click', () => {
    const name = document.getElementById('r-name').value.trim();
    const capacity = +document.getElementById('r-capacity').value || 0;
    const equip = document.getElementById('r-equip').value.trim();
    if (!name || !capacity) return alert('Please fill room name and capacity.');
    state.rooms.push({ name, capacity, equip });
    renderTable();
  });
  const addFaculty = document.getElementById('addFaculty');
  if (addFaculty) addFaculty.addEventListener('click', () => {
    const name = document.getElementById('f-name').value.trim();
    const courses = document.getElementById('f-courses').value.trim();
    const load = +document.getElementById('f-load').value || 0;
    if (!name || !load) return alert('Please fill faculty name and load.');
    state.faculty.push({ name, courses, load });
    renderTable();
  });

  const saveConstraints = document.getElementById('saveConstraints');
  const resetConstraints = document.getElementById('resetConstraints');
  if (saveConstraints) saveConstraints.addEventListener('click', () => {
    const days = Array.from(document.getElementById('days').selectedOptions).map(o=>o.value);
    const slots = +document.getElementById('slots').value || 6;
    const slotLen = +document.getElementById('slotLen').value || 60;
    const windows = document.getElementById('windows').value;
    state.constraints = { days: days.length?days:['Mon','Tue','Wed','Thu','Fri'], slots, slotLen, windows };
    alert('Constraints saved.');
  });
  if (resetConstraints) resetConstraints.addEventListener('click', () => {
    document.getElementById('days').selectedIndex = -1;
    document.getElementById('slots').value = 6;
    document.getElementById('slotLen').value = 60;
    document.getElementById('windows').value = '';
    state.constraints = { days: ['Mon','Tue','Wed','Thu','Fri'], slots: 6, slotLen: 60, windows: '' };
  });

  const timetableBody = document.getElementById('timetableBody');
  const genStatus = document.getElementById('genStatus');
  const generateBtn = document.getElementById('generateBtn');
  if (generateBtn) generateBtn.addEventListener('click', () => {
    const { days, slots } = state.constraints;
    if (!days.length || !slots) return alert('Please set constraints first.');
    const cells = [];
    for (let d of days) {
      const row = [d];
      for (let s=0; s<slots; s++) {
        const c = state.courses[(s) % Math.max(state.courses.length,1)];
        row.push(c ? c.code : '-');
      }
      cells.push(row);
    }
    state.timetable = cells;
    if (timetableBody) timetableBody.innerHTML = cells.map(r => `<tr class="border-b border-zinc-100 dark:border-zinc-800">${r.map((v)=>`<td class='py-2 pr-6'>${v}</td>`).join('')}</tr>`).join('');
    if (genStatus) genStatus.textContent = 'Generated sample timetable (demo).';
  });

  const exportCSV = document.getElementById('exportCSV');
  if (exportCSV) exportCSV.addEventListener('click', () => {
    const rows = state.timetable;
    if (!rows.length) return alert('Generate a timetable first.');
    const csv = rows.map(r => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'timetable.csv'; a.click();
    URL.revokeObjectURL(url);
  });
  const exportJSON = document.getElementById('exportJSON');
  if (exportJSON) exportJSON.addEventListener('click', () => {
    const blob = new Blob([JSON.stringify({ ...state }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = 'scheduler_state.json'; a.click();
    URL.revokeObjectURL(url);
  });
  const printPDF = document.getElementById('printPDF');
  if (printPDF) printPDF.addEventListener('click', () => {
    window.print();
  });

  renderTable();
})();
