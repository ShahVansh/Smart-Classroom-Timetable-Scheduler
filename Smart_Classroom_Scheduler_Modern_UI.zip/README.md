# Smart Classroom Scheduler – Modern Frontend

A clean, professional, and responsive UI for a timetable/scheduler app. Built with Tailwind (CDN), no build step required.

## Structure
- `index.html` – landing page with CTA
- `pages/scheduler.html` – data entry forms, constraints, and demo timetable generator
- `pages/analytics.html` – sample charts via Chart.js
- `pages/about.html`, `pages/help.html`
- `assets/app.js`, `assets/logo.svg`, `assets/hero-dashboard.png`

## Usage
Open `index.html` in a browser. Use Theme button to toggle dark mode.
Export CSV/JSON from Scheduler -> Generate -> Export.

You can plug your real generation backend by replacing the mock generator in `assets/app.js` (search for "placeholder algorithm").
